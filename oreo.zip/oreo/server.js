var express = require('express');
var path = require('path')
var fileUpload = require('express-fileupload');
var favicon = require('serve-favicon');

var port = process.env.PORT || 3000;


var i;
const testFolder = './output/';
const fs = require('fs');

var app = express();
app.use(fileUpload());
app.use(favicon(__dirname + '/favicon.ico'));

console.log("__dirname : " + __dirname + " __filename : " + __filename);

app.use(express.static(__dirname));

app.get('/files',function(req,res){
   /*  fs.readdir(testFolder, (err, files) => {
        files.forEach(file => {
          console.log(file);
          
        });
        
      }) */

      /*  fs.readdirSync(testFolder).forEach(file => {
        console.log(file);
      })
      res.redirect("back");*/

      var walk    = require('walk');
var files   = [];

// Walker options
var walker  = walk.walk('./output', { followLinks: false });

walker.on('file', function(root, stat, next) {
    // Add this file to the list of files
    files.push(root + '/' + stat.name);
    next();
});

walker.on('end', function() {
    console.log(files);
    res.send(JSON.stringify(files));
});

//res.redirect("back");
})

app.post('/upload', function (req, res) {
    if (!req.files)
        return res.status(400).send('No files were uploaded.');
       /*  if(window.localStorage.getItem("id") != null && window.localStorage.getItem("id") != undefined){
            i = window.localStorage.getItem("id");
            i = i+1;
            window.localStorage.setItem("id",i);
        } */
    
    // The name of the input field (i.e. "sampleFile") is used to retrieve the uploaded file
    let userFile = req.files.userFile;
    console.log("userfile nmae: ",userFile.name);

    // Use the mv() method to place the file somewhere on your server
    userFile.mv(__dirname + '/output/'+userFile.name, function (err) {
        if (err)
            return res.status(500).send(err);
        console.log("File uploaded witht the name newFile.obj**");
        res.redirect("back");
    });
});

app.use(express.static(path.join(__dirname, 'public')));

app.listen(port, function () {
    console.log("app listening on port gfdfdd: ",port);
})
